python /home/aish/sumo-0.32.0/tools/randomTrips.py -n seoul.net.xml  -r seoul.rou.xml  --period 0.2
duarouter --net=seoul.net.xml -r seoul.rou.xml  --output-file=dua.rou.xml  --xml-validation never


python atom.py 


 

